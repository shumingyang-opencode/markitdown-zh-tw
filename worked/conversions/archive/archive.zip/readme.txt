Hello from a ZIP file!
